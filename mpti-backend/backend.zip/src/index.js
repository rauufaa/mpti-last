
import { web } from "./application/web.js";

web.listen(3000, ()=>{
    console.log("Running on port 3000")
})
